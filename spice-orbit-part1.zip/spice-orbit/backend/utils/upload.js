import multer from 'multer';
import { v2 as cloudinary } from 'cloudinary';
cloudinary.config({ cloud_name: process.env.CLOUDINARY_CLOUD_NAME, api_key: process.env.CLOUDINARY_API_KEY, api_secret: process.env.CLOUDINARY_API_SECRET });
export const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_r, f, cb) => f.mimetype.startsWith('image/') ? cb(null, true) : cb(new Error('Images only')) });
export const uploadToCloud = buf => new Promise((resolve, reject) =>
  cloudinary.uploader.upload_stream({ folder: 'spice-orbit', format: 'webp', quality: 'auto' }, (e, r) => e ? reject(e) : resolve(r.secure_url)).end(buf));
