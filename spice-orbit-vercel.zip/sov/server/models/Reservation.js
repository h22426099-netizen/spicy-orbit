import mongoose from 'mongoose';
export default mongoose.model('Reservation', new mongoose.Schema({
  name: { type: String, required: true }, email: { type: String, required: true }, phone: String,
  date: { type: String, required: true }, time: { type: String, required: true },
  guests: { type: Number, required: true, min: 1, max: 30 }, request: String,
  status: { type: String, enum: ['pending', 'confirmed', 'cancelled'], default: 'pending' },
}, { timestamps: true }));
