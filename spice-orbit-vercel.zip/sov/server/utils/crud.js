import { wrap } from '../middleware/error.js';
export const crud = (Model) => ({
  list: wrap(async (req, res) => res.json(await Model.find(req.filter || {}).sort(req.sort || '-createdAt'))),
  create: wrap(async (req, res) => res.status(201).json(await Model.create(req.body))),
  update: wrap(async (req, res) => {
    const doc = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    doc ? res.json(doc) : res.status(404).json({ message: 'Not found' });
  }),
  remove: wrap(async (req, res) => {
    const doc = await Model.findByIdAndDelete(req.params.id);
    doc ? res.json({ message: 'Deleted' }) : res.status(404).json({ message: 'Not found' });
  }),
});
