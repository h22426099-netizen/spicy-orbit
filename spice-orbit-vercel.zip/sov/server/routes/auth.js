import { Router } from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { body, validationResult } from 'express-validator';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';
import { wrap } from '../middleware/error.js';
import { sendMail } from '../utils/mailer.js';

const r = Router();
const sign = id => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES || '7d' });
const out = u => ({ _id: u._id, name: u.name, email: u.email, role: u.role, phone: u.phone });
const check = (req, res, next) => {
  const e = validationResult(req);
  return e.isEmpty() ? next() : res.status(400).json({ message: e.array()[0].msg });
};

r.post('/signup', [body('name').notEmpty().withMessage('Name required'), body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password min 6 chars')], check, wrap(async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (await User.findOne({ email })) return res.status(409).json({ message: 'Email already registered' });
  const u = await User.create({ name, email, password, phone });
  res.status(201).json({ token: sign(u._id), user: out(u) });
}));

r.post('/login', wrap(async (req, res) => {
  const u = await User.findOne({ email: req.body.email }).select('+password');
  if (!u || !(await u.matchPassword(req.body.password))) return res.status(401).json({ message: 'Invalid credentials' });
  res.json({ token: sign(u._id), user: out(u) });
}));

r.get('/me', protect, (req, res) => res.json(out(req.user)));

r.post('/forgot-password', wrap(async (req, res) => {
  const u = await User.findOne({ email: req.body.email });
  if (u) {
    const token = crypto.randomBytes(32).toString('hex');
    u.resetToken = crypto.createHash('sha256').update(token).digest('hex');
    u.resetExpires = Date.now() + 30 * 60 * 1000;
    await u.save();
    await sendMail(u.email, 'Reset your Spice Orbit password',
      `<p>Reset link (valid 30 min): <a href="${process.env.CLIENT_URL}/reset-password/${token}">Reset password</a></p>`);
  }
  res.json({ message: 'If that email exists, a reset link was sent.' });
}));

r.post('/reset-password/:token', wrap(async (req, res) => {
  const hash = crypto.createHash('sha256').update(req.params.token).digest('hex');
  const u = await User.findOne({ resetToken: hash, resetExpires: { $gt: Date.now() } });
  if (!u) return res.status(400).json({ message: 'Token invalid or expired' });
  u.password = req.body.password; u.resetToken = undefined; u.resetExpires = undefined;
  await u.save();
  res.json({ token: sign(u._id), user: out(u) });
}));

// profile, addresses, favorites, cart sync
r.put('/profile', protect, wrap(async (req, res) => {
  const { name, phone, addresses } = req.body;
  Object.assign(req.user, { ...(name && { name }), ...(phone && { phone }), ...(addresses && { addresses }) });
  await req.user.save(); res.json(out(req.user));
}));
r.post('/favorites/:dishId', protect, wrap(async (req, res) => {
  const f = req.user.favorites.map(String), id = req.params.dishId;
  req.user.favorites = f.includes(id) ? f.filter(x => x !== id) : [...f, id];
  await req.user.save(); res.json(req.user.favorites);
}));
r.get('/favorites', protect, wrap(async (req, res) => res.json((await req.user.populate('favorites')).favorites)));
r.put('/cart', protect, wrap(async (req, res) => { req.user.cart = req.body.items || []; await req.user.save(); res.json(req.user.cart); }));
r.get('/cart', protect, wrap(async (req, res) => res.json((await req.user.populate('cart.dish')).cart)));

export default r;
