# Images & Video (frontend/public/images/...  — save as WebP)
Dish images go in `public/images/dishes/<dish-slug>.webp`. Missing images show a gradient fallback automatically.
| File | AI prompt (Midjourney / DALL·E / Canva AI) |
|---|---|
| hero-poster.webp | Cinematic wide shot of a Pakistani charcoal grill with flames and skewers, dark moody restaurant, warm light, 8k |
| about.webp | Chef in white apron grilling kebabs over charcoal, smoke, warm golden light, documentary style |
| categories/bbq-grill.webp | Assorted BBQ platter tikka, seekh kebab, malai boti, charcoal smoke, dark slate, 8k food photography |
| categories/karahi-handi.webp | Chicken karahi in black wok, steam, ginger and green chilli garnish, dark background |
| categories/biryani-rice.webp | Karachi chicken biryani in copper pot, saffron rice, lemon wedge, steam |
| categories/breads-sides.webp | Fresh naan in tandoor basket with raita and salad, rustic wood |
| categories/desserts-drinks.webp | Gulab jamun, kheer and sweet lassi on a brass tray, dark moody |
| gallery/*.webp (grill, karahi, biryani, naan, dessert, interior, chef, tikka, lassi) | Same style prompts + "Karachi restaurant interior, warm lights" for `interior` |
Each dish's exact prompt is stored in `backend/seed.js` (`aiPrompt`).

## Hero video (set `VITE_HERO_VIDEO` in frontend/.env, or put an .mp4 in public/videos/hero.mp4 and use /videos/hero.mp4)
- Free stock: search "chef cooking fire" on https://www.pexels.com/search/videos/chef%20cooking%20fire/ or https://pixabay.com/videos/search/grill/ — download a 1080p MP4 (compress < 8 MB, e.g. HandBrake).
- AI prompt (Runway / Pika / Sora): "Cinematic slow-motion shot of a chef cooking in flames, sizzling pan, steam, warm lighting, restaurant kitchen, 4K, 10 seconds seamless loop"
- "Our Story" video (modal) – add a `<video>` in a modal on About page with the prompt: "Documentary montage of a Karachi family restaurant: hand-grinding spices, charcoal lighting, plating biryani, 4K".
