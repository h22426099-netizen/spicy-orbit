import nodemailer from 'nodemailer';
const tx = () => nodemailer.createTransport({
  host: process.env.SMTP_HOST, port: +process.env.SMTP_PORT || 587,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});
export async function sendMail(to, subject, html) {
  if (!process.env.SMTP_USER) return console.log(`[mail skipped] ${subject} -> ${to}`);
  try { await tx().sendMail({ from: `"Spice Orbit" <${process.env.SMTP_USER}>`, to, subject, html }); }
  catch (e) { console.error('Mail error:', e.message); }
}
export const orderEmail = o => `<div style="font-family:Arial;max-width:560px;margin:auto">
<h2 style="color:#b91c1c">Spice Orbit – Order ${o.orderId}</h2>
<p>Thanks ${o.customer.name}! Your ${o.orderType} order is received.</p>
<ul>${o.items.map(i => `<li>${i.qty} × ${i.name}${i.size ? ' (' + i.size + ')' : ''} — Rs ${i.price * i.qty}</li>`).join('')}</ul>
<p><b>Total: Rs ${o.total}</b> (${o.payment.method.toUpperCase()})</p></div>`;
