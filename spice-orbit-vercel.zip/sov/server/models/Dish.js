import mongoose from 'mongoose';
const dishSchema = new mongoose.Schema({
  name: { type: String, required: true }, slug: { type: String, unique: true },
  description: String, price: { type: Number, required: true, min: 0 },
  image: String, aiPrompt: String,
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  isVeg: { type: Boolean, default: false }, spicy: { type: Number, min: 0, max: 3, default: 0 },
  rating: { type: Number, default: 4.5 }, numReviews: { type: Number, default: 0 },
  ingredients: [String],
  sizes: [{ name: String, priceDelta: { type: Number, default: 0 } }],
  addons: [{ name: String, price: Number }],
  featured: { type: Boolean, default: false }, chefSpecial: { type: Boolean, default: false },
  available: { type: Boolean, default: true },
}, { timestamps: true });
dishSchema.index({ name: 'text', description: 'text' });
dishSchema.pre('validate', function (next) {
  if (!this.slug && this.name) this.slug = this.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  next();
});
export default mongoose.model('Dish', dishSchema);
