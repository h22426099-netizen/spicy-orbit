import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import api from '../api';
import { useApp } from '../context';
import { Page, Field } from '../components/ui';
import { useQuote, Summary } from './Cart';
const stripePromise = import.meta.env.VITE_STRIPE_PK ? loadStripe(import.meta.env.VITE_STRIPE_PK) : null;
const schema = z.object({ name: z.string().min(2, 'Name required'), phone: z.string().regex(/^(\+92|0)?3\d{9}$/, 'Enter a valid Pakistani mobile number'),
  email: z.string().email('Valid email required'), address: z.string().optional(), city: z.string().default('Karachi'), deliveryTime: z.string().optional(), notes: z.string().optional(), payment: z.enum(['cod', 'stripe']) });
function Pay({ orderId, done }) {
  const stripe = useStripe(), el = useElements(); const [busy, setBusy] = useState(false);
  return <form onSubmit={async e => { e.preventDefault(); setBusy(true); const { error } = await stripe.confirmPayment({ elements: el, redirect: 'if_required' });
    if (error) { toast.error(error.message); setBusy(false); } else { await api.post(`/orders/${orderId}/confirm-payment`); done(); } }} className="glass p-6 space-y-4"><PaymentElement />
    <button disabled={busy} className="btn btn-primary w-full">{busy ? 'Processing…' : 'Pay now (test card 4242…)'}</button></form>;
}
export default function Checkout() {
  const { cart, clear, coupon, orderType, user } = useApp(); const nav = useNavigate(); const q = useQuote(); const [pay, setPay] = useState(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(schema), defaultValues: { name: user?.name, email: user?.email, phone: user?.phone, city: 'Karachi', payment: 'cod' } });
  const finish = id => { clear(); nav('/confirmation/' + id); };
  const submit = async v => { try {
    const r = await api.post('/orders', { items: cart.map(({ dish, qty, size, addons }) => ({ dish, qty, size, addons })), orderType, coupon, paymentMethod: v.payment,
      customer: { name: v.name, phone: v.phone, email: v.email }, address: { line: v.address, city: v.city }, deliveryTime: v.deliveryTime, notes: v.notes });
    r.clientSecret ? setPay({ id: r.order.orderId, secret: r.clientSecret }) : finish(r.order.orderId);
  } catch (e) { toast.error(e.message); } };
  if (!cart.length && !pay) return <Page title="Checkout"><p>Your cart is empty.</p></Page>;
  if (pay) return <Page title="Payment"><div className="max-w-lg"><Elements stripe={stripePromise} options={{ clientSecret: pay.secret }}><Pay orderId={pay.id} done={() => finish(pay.id)} /></Elements></div></Page>;
  return <Page title="Checkout"><form onSubmit={handleSubmit(submit)} className="grid lg:grid-cols-3 gap-8" noValidate>
    <div className="lg:col-span-2 glass p-6 grid sm:grid-cols-2 gap-4">
      <Field label="Full name" error={errors.name}><input className="input" {...register('name')} /></Field><Field label="Phone" error={errors.phone}><input className="input" placeholder="03XXXXXXXXX" {...register('phone')} /></Field>
      <Field label="Email" error={errors.email}><input className="input" {...register('email')} /></Field><Field label="City"><input className="input" {...register('city')} /></Field>
      {orderType === 'delivery' && <div className="sm:col-span-2"><Field label="Delivery address"><input className="input" {...register('address')} /></Field></div>}
      <Field label="Preferred time"><input type="time" className="input" {...register('deliveryTime')} /></Field>
      <Field label="Payment"><select className="input" {...register('payment')}><option value="cod">Cash on Delivery</option>{stripePromise && <option value="stripe">Card (Stripe)</option>}</select></Field>
      <div className="sm:col-span-2"><Field label="Special instructions"><textarea rows={3} className="input" {...register('notes')} /></Field></div></div>
    <div className="space-y-4"><p className="text-sm">Order type: <b className="capitalize">{orderType}</b></p><Summary q={q} /><button disabled={isSubmitting} className="btn btn-primary w-full">{isSubmitting ? 'Placing…' : 'Place order'}</button></div></form></Page>;
}
