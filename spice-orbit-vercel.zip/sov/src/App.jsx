import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import { useApp } from './context';
import Home from './pages/Home';
import Menu from './pages/Menu';
import Dish from './pages/Dish';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Confirm from './pages/Confirm';
import Track from './pages/Track';
import Auth from './pages/Auth';
import Profile from './pages/Profile';
import { Reserve, Contact } from './pages/Forms';
import { About, FAQ, Gallery, Offers, Blog, Reviews, Privacy, Terms, NotFound } from './pages/Info';
const Admin = lazy(() => import('./pages/Admin'));
const Guard = ({ admin, children }) => { const { user } = useApp(); return !user ? <Navigate to="/login" /> : admin && user.role !== 'admin' ? <Navigate to="/" /> : children; };
export default function App() {
  return <Routes><Route element={<Layout />}>
    <Route index element={<Home />} /><Route path="menu" element={<Menu />} /><Route path="order" element={<Menu order />} /><Route path="dish/:slug" element={<Dish />} />
    <Route path="cart" element={<Cart />} /><Route path="checkout" element={<Checkout />} /><Route path="confirmation/:id" element={<Confirm />} /><Route path="track" element={<Track />} />
    <Route path="reservation" element={<Reserve />} /><Route path="gallery" element={<Gallery />} /><Route path="offers" element={<Offers />} /><Route path="blog" element={<Blog />} />
    <Route path="reviews" element={<Reviews />} /><Route path="about" element={<About />} /><Route path="contact" element={<Contact />} /><Route path="faq" element={<FAQ />} />
    <Route path="login" element={<Auth mode="login" />} /><Route path="signup" element={<Auth mode="signup" />} /><Route path="forgot-password" element={<Auth mode="forgot" />} /><Route path="reset-password/:token" element={<Auth mode="reset" />} />
    <Route path="profile" element={<Guard><Profile /></Guard>} /><Route path="admin" element={<Guard admin><Suspense fallback={null}><Admin /></Suspense></Guard>} />
    <Route path="privacy" element={<Privacy />} /><Route path="terms" element={<Terms />} /><Route path="*" element={<NotFound />} /></Route></Routes>;
}
