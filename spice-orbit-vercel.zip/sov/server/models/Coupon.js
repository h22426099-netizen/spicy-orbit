import mongoose from 'mongoose';
export default mongoose.model('Coupon', new mongoose.Schema({
  code: { type: String, required: true, unique: true, uppercase: true },
  type: { type: String, enum: ['percent', 'fixed'], default: 'percent' },
  value: { type: Number, required: true }, minOrder: { type: Number, default: 0 },
  expiresAt: Date, active: { type: Boolean, default: true }, usedCount: { type: Number, default: 0 },
}, { timestamps: true }));
