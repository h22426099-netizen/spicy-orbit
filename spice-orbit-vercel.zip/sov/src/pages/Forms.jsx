import { useState } from 'react';
import toast from 'react-hot-toast';
import { Phone, Clock, MessageCircle } from 'lucide-react';
import api from '../api';
import { Page } from '../components/ui';
const WA = import.meta.env.VITE_WHATSAPP || '923001234567';
const useForm2 = (url, ok, init = {}) => { const [f, setF] = useState(init); return [f, k => e => setF({ ...f, [k]: e.target.value }), async e => { e.preventDefault(); try { await api.post(url, f); toast.success(ok); e.target.reset(); setF(init); } catch (x) { toast.error(x.message); } }]; };
export function Reserve() {
  const [f, s, submit] = useForm2('/reservations', 'Request sent! Check your email.', { guests: 2 });
  return <Page title="Book a Table"><form onSubmit={submit} className="glass p-8 max-w-2xl grid sm:grid-cols-2 gap-4">
    <input required className="input" placeholder="Name" onChange={s('name')} /><input required type="email" className="input" placeholder="Email" onChange={s('email')} />
    <input className="input" placeholder="Phone" onChange={s('phone')} /><input required type="number" min="1" max="30" className="input" placeholder="Guests" defaultValue={2} onChange={s('guests')} />
    <input required type="date" min={new Date().toISOString().slice(0, 10)} className="input" onChange={s('date')} /><input required type="time" className="input" onChange={s('time')} />
    <textarea className="input sm:col-span-2" rows={3} placeholder="Special request" onChange={s('request')} /><button className="btn btn-primary sm:col-span-2">Reserve</button></form></Page>;
}
export function Contact() {
  const [f, s, submit] = useForm2('/contact', 'Message sent!');
  return <Page title="Contact Us"><div className="grid md:grid-cols-2 gap-8"><div className="space-y-4">
    <form onSubmit={submit} className="glass p-6 space-y-3"><input required className="input" placeholder="Name" onChange={s('name')} /><input required type="email" className="input" placeholder="Email" onChange={s('email')} /><textarea required rows={4} className="input" placeholder="Message" onChange={s('message')} /><button className="btn btn-primary w-full">Send</button></form>
    <div className="glass p-6 space-y-2 text-sm"><p className="flex gap-2"><Phone size={16} />+92 300 1234567</p><p className="flex gap-2"><Clock size={16} />Daily 12pm – 1am</p><a className="btn btn-primary !bg-green-500 mt-2" href={`https://wa.me/${WA}`}><MessageCircle size={16} />WhatsApp us</a></div></div>
    <iframe title="Map" className="w-full min-h-[380px] rounded-2xl" loading="lazy" src="https://www.google.com/maps?q=Clifton,Karachi&output=embed" /></div></Page>;
}
