import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Leaf, Truck, ChefHat, ShieldCheck, ChevronDown } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../api';
import DishCard from '../components/DishCard';
import { Section, Reveal, Counter, Img, Stars, Skeletons } from '../components/ui';
const video = import.meta.env.VITE_HERO_VIDEO;
const words = 'Taste the Orbit of Real Pakistani Spice'.split(' ');
const reviews = [['Ayesha R.', 'The karahi is unreal. Smoky, spicy, perfect.', 5], ['Hamza S.', 'Fastest delivery in Clifton and biryani was piping hot.', 5], ['Sana M.', 'Great family dining spot, loved the malai boti.', 4]];
function Countdown() {
  const [t, setT] = useState(0);
  useEffect(() => { const f = () => { const e = new Date(); e.setHours(23, 59, 59, 0); setT(Math.max(0, e - Date.now())); }; f(); const i = setInterval(f, 1000); return () => clearInterval(i); }, []);
  const p = n => String(Math.floor(n)).padStart(2, '0');
  return <div className="flex gap-3">{[['Hrs', t / 36e5], ['Min', t / 6e4 % 60], ['Sec', t / 1e3 % 60]].map(([l, v]) => <div key={l} className="bg-black/30 rounded-xl px-4 py-2 text-center"><div className="text-3xl font-bold tabular-nums">{p(v)}</div><div className="text-xs">{l}</div></div>)}</div>;
}
export default function Home() {
  const [dishes, setDishes] = useState(null); const [cats, setCats] = useState([]); const { scrollY } = useScroll(); const y = useTransform(scrollY, [0, 600], [0, 150]);
  useEffect(() => { document.title = 'Spice Orbit | Pakistani Restaurant Karachi'; api.get('/dishes?featured=true&limit=8').then(d => setDishes(d.items)).catch(() => setDishes([])); api.get('/categories').then(setCats).catch(() => {}); }, []);
  return <>
    <section className="relative h-screen min-h-[600px] overflow-hidden grid place-items-center text-white text-center">
      {video ? <video className="absolute inset-0 w-full h-full object-cover" src={video} autoPlay muted loop playsInline poster="/images/hero-poster.webp" /> : <div className="absolute inset-0 bg-gradient-to-br from-brand via-orange-700 to-night" />}
      <div className="absolute inset-0 bg-black/60" />
      {['🌶️', '🌿', '🧄', '⭐'].map((e, i) => <motion.span key={i} style={{ y }} className="absolute text-4xl sm:text-6xl animate-float opacity-70" ><span style={{ position: 'absolute', left: `${10 + i * 25}vw`, top: `${15 + (i % 2) * 55}vh`, animationDelay: `${i}s` }}>{e}</span></motion.span>)}
      <div className="relative z-10 container-x"><p className="text-gold tracking-[.4em] uppercase text-xs sm:text-sm mb-4">Spice Orbit · Karachi</p>
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold leading-tight max-w-4xl mx-auto">{words.map((w, i) => <span key={i} className="inline-block overflow-hidden mr-3"><motion.span className="inline-block" initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ delay: 1.5 + i * .12, duration: .7 }}>{w}</motion.span></span>)}</h1>
        <p className="mt-6 text-lg opacity-90">Charcoal BBQ · Karahi · Dum Biryani</p>
        <div className="mt-8 flex flex-wrap gap-4 justify-center"><Link to="/order" className="btn btn-primary">Order Now</Link><Link to="/menu" className="btn btn-ghost">View Menu</Link></div></div>
      <div className="absolute bottom-6 z-10 flex flex-col items-center gap-1 text-xs"><div className="w-6 h-10 border-2 rounded-full flex justify-center pt-2"><i className="w-1 h-2 bg-white rounded animate-wheel" /></div><ChevronDown size={16} /></div>
    </section>
    <div className="bg-brand text-white py-3 overflow-hidden whitespace-nowrap"><div className="inline-block animate-marquee">{Array(8).fill('★ FRESH ★ FLAMING ★ FAST DELIVERY ').join('')}</div></div>
    <Section title="Our Story in Flames" sub="About us"><div className="grid md:grid-cols-2 gap-10 items-center">
      <Reveal><Img src="/images/about.webp" alt="Chef grilling" className="rounded-3xl w-full aspect-[4/3] object-cover shadow-2xl" /></Reveal>
      <Reveal delay={.1}><p className="text-lg opacity-80 mb-8">From a small street-side grill in Saddar to Karachi's favourite table, Spice Orbit is built on family recipes, hand-ground masalas and real charcoal.</p>
        <div className="grid grid-cols-3 gap-4 text-center">{[[12, '+', 'Years'], [50000, '+', 'Customers'], [120, '+', 'Dishes']].map(([n, s, l]) => <div key={l} className="glass p-4"><div className="text-3xl font-bold text-gold"><Counter to={n} suffix={s} /></div><div className="text-sm">{l}</div></div>)}</div>
        <Link to="/about" className="btn btn-ghost mt-8">Learn more</Link></Reveal></div></Section>
    <Section title="Popular Dishes" sub="Customer favourites">{!dishes ? <Skeletons n={3} /> : dishes.length ? <div className="flex gap-6 overflow-x-auto snap-x snap-mandatory pb-4 -mx-4 px-4">{dishes.map((d, i) => <div key={d._id} className="snap-start shrink-0 w-[85%] sm:w-[45%] lg:w-[31%]"><DishCard d={d} i={i} /></div>)}</div> : <p className="text-center opacity-60">Run the seed script to see dishes.</p>}</Section>
    <Section title="Explore the Menu" sub="Categories"><div className="grid grid-cols-2 lg:grid-cols-5 gap-4">{cats.map(c => <Link key={c._id} to={`/menu?category=${c.slug}`} className="relative aspect-square rounded-2xl overflow-hidden group"><Img src={c.image} alt={c.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" /><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-4 text-white font-heading text-lg font-bold">{c.name}</div></Link>)}</div></Section>
    <section className="container-x"><div className="rounded-3xl bg-gradient-to-r from-brand to-orange-500 text-white p-8 sm:p-14 flex flex-wrap items-center justify-between gap-8"><div><p className="uppercase tracking-widest text-xs">Deal of the day</p><h2 className="text-3xl sm:text-5xl font-bold my-2">Family Feast – 20% OFF</h2><p>Use code <b className="bg-black/30 px-2 py-1 rounded">WELCOME10</b> on orders over Rs 1,000</p></div><div className="space-y-4"><Countdown /><Link to="/offers" className="btn bg-white text-brand">Grab the deal</Link></div></div></section>
    <Section title="Why Choose Us" sub="The Spice Orbit promise"><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">{[[Leaf, 'Fresh Ingredients', 'Sourced daily from local farms.'], [Truck, 'Fast Delivery', 'Hot at your door in 45 min.'], [ChefHat, 'Master Chefs', 'Recipes perfected over decades.'], [ShieldCheck, 'Hygiene First', 'Certified, spotless kitchen.']].map(([I, t, d], i) => <Reveal key={t} delay={i * .1}><div className="glass p-6 text-center h-full hover:-translate-y-2 transition"><I className="mx-auto text-brand mb-3" size={36} /><h3 className="font-bold text-lg">{t}</h3><p className="text-sm opacity-70">{d}</p></div></Reveal>)}</div></Section>
    <Section title="Guests Love Us" sub="Testimonials"><div className="grid md:grid-cols-3 gap-6">{reviews.map(([n, t, r]) => <Reveal key={n}><div className="glass p-6"><Stars n={r} /><p className="my-3 italic">“{t}”</p><p className="font-semibold text-gold">{n}</p></div></Reveal>)}</div></Section>
    <Section title="Join the Orbit" sub="Newsletter"><form className="max-w-xl mx-auto flex gap-3 flex-wrap" onSubmit={async e => { e.preventDefault(); try { await api.post('/newsletter', { email: e.target.email.value }); toast.success('Subscribed!'); e.target.reset(); } catch (x) { toast.error(x.message); } }}>
      <input name="email" type="email" required placeholder="you@email.com" className="input flex-1" aria-label="Email" /><button className="btn btn-primary">Subscribe</button></form></Section></>;
}
