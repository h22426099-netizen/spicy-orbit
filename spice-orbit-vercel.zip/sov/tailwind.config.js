export default { darkMode: 'class', content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { brand: '#b91c1c', gold: '#d4a017', cream: '#fff8ee', night: '#14100d' },
    fontFamily: { heading: ['"Playfair Display"', 'serif'], body: ['Poppins', 'sans-serif'] },
    keyframes: { float: { '0%,100%': { transform: 'translateY(0) rotate(0)' }, '50%': { transform: 'translateY(-24px) rotate(12deg)' } },
      marquee: { to: { transform: 'translateX(-50%)' } }, wheel: { '0%': { opacity: 1, transform: 'translateY(0)' }, '100%': { opacity: 0, transform: 'translateY(12px)' } } },
    animation: { float: 'float 6s ease-in-out infinite', marquee: 'marquee 25s linear infinite', wheel: 'wheel 1.4s infinite' } } }, plugins: [] };
