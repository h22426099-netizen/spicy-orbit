import { Router } from 'express';
import Dish from '../models/Dish.js';
import Category from '../models/Category.js';
import { protect, adminOnly } from '../middleware/auth.js';
import { wrap } from '../middleware/error.js';
import { upload, uploadToCloud } from '../utils/upload.js';

const r = Router();

// GET /api/dishes?category=slug&search=&veg=true&spicy=2&min=&max=&sort=price|-price|rating&page=1&limit=12&featured=true
r.get('/', wrap(async (req, res) => {
  const { category, search, veg, spicy, min, max, sort = '-rating', page = 1, limit = 12, featured, chef } = req.query;
  const q = { available: true };
  if (category) { const c = await Category.findOne({ slug: category }); q.category = c?._id; }
  if (search) q.$text = { $search: search };
  if (veg === 'true') q.isVeg = true; if (veg === 'false') q.isVeg = false;
  if (spicy) q.spicy = { $gte: +spicy };
  if (min || max) q.price = { ...(min && { $gte: +min }), ...(max && { $lte: +max }) };
  if (featured === 'true') q.featured = true;
  if (chef === 'true') q.chefSpecial = true;
  const total = await Dish.countDocuments(q);
  const items = await Dish.find(q).populate('category', 'name slug').sort(sort)
    .skip((+page - 1) * +limit).limit(+limit);
  res.json({ items, total, page: +page, pages: Math.ceil(total / +limit) });
}));

r.get('/:slug', wrap(async (req, res) => {
  const dish = await Dish.findOne({ slug: req.params.slug }).populate('category', 'name slug');
  if (!dish) return res.status(404).json({ message: 'Dish not found' });
  const related = await Dish.find({ category: dish.category._id, _id: { $ne: dish._id } }).limit(4);
  res.json({ dish, related });
}));

const parse = body => {
  const d = { ...body };
  ['ingredients', 'sizes', 'addons'].forEach(k => { if (typeof d[k] === 'string') try { d[k] = JSON.parse(d[k]); } catch {} });
  return d;
};
r.post('/', protect, adminOnly, upload.single('image'), wrap(async (req, res) => {
  const d = parse(req.body); if (req.file) d.image = await uploadToCloud(req.file.buffer);
  res.status(201).json(await Dish.create(d));
}));
r.put('/:id', protect, adminOnly, upload.single('image'), wrap(async (req, res) => {
  const d = parse(req.body); if (req.file) d.image = await uploadToCloud(req.file.buffer);
  res.json(await Dish.findByIdAndUpdate(req.params.id, d, { new: true, runValidators: true }));
}));
r.delete('/:id', protect, adminOnly, wrap(async (req, res) => { await Dish.findByIdAndDelete(req.params.id); res.json({ message: 'Deleted' }); }));

export default r;
