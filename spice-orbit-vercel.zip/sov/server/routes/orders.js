import { Router } from 'express';
import Stripe from 'stripe';
import Order from '../models/Order.js';
import Dish from '../models/Dish.js';
import Coupon from '../models/Coupon.js';
import { protect, adminOnly, optionalAuth } from '../middleware/auth.js';
import { wrap } from '../middleware/error.js';
import { sendMail, orderEmail } from '../utils/mailer.js';

const r = Router();
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

async function price(items, orderType, couponCode) {
  const dishes = await Dish.find({ _id: { $in: items.map(i => i.dish) } });
  const lines = items.map(i => {
    const d = dishes.find(x => String(x._id) === String(i.dish));
    if (!d || !d.available) throw Object.assign(new Error('Item unavailable'), { status: 400 });
    const size = d.sizes.find(s => s.name === i.size);
    const addons = (i.addons || []).map(n => d.addons.find(a => a.name === n)).filter(Boolean);
    const unit = d.price + (size?.priceDelta || 0) + addons.reduce((s, a) => s + a.price, 0);
    return { dish: d._id, name: d.name, image: d.image, price: unit, qty: Math.max(1, +i.qty || 1), size: i.size, addons: addons.map(a => a.name) };
  });
  const subtotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
  let discount = 0, coupon;
  if (couponCode) {
    coupon = await Coupon.findOne({ code: couponCode.toUpperCase(), active: true });
    if (coupon && (!coupon.expiresAt || coupon.expiresAt > new Date()) && subtotal >= coupon.minOrder)
      discount = coupon.type === 'percent' ? Math.round(subtotal * coupon.value / 100) : Math.min(coupon.value, subtotal);
    else coupon = null;
  }
  const tax = Math.round((subtotal - discount) * +(process.env.TAX_RATE || 0.05));
  const deliveryFee = orderType === 'delivery' && subtotal < +(process.env.FREE_DELIVERY_OVER || 3000) ? +(process.env.DELIVERY_FEE || 150) : 0;
  return { lines, subtotal, discount, tax, deliveryFee, total: subtotal - discount + tax + deliveryFee, coupon };
}

// Validate a coupon + preview totals
r.post('/quote', wrap(async (req, res) => {
  const { lines, ...totals } = await price(req.body.items, req.body.orderType, req.body.coupon);
  res.json({ ...totals, coupon: totals.coupon?.code || null });
}));

// Create order (guest or logged-in)
r.post('/', optionalAuth, wrap(async (req, res) => {
  const { items, orderType = 'delivery', customer, address, deliveryTime, notes, paymentMethod = 'cod', coupon: code } = req.body;
  if (!items?.length) return res.status(400).json({ message: 'Cart is empty' });
  if (!customer?.name || !customer?.phone) return res.status(400).json({ message: 'Name and phone required' });
  if (orderType === 'delivery' && !address?.line) return res.status(400).json({ message: 'Delivery address required' });

  const p = await price(items, orderType, code);
  let intent;
  if (paymentMethod === 'stripe') {
    if (!stripe) return res.status(400).json({ message: 'Stripe not configured' });
    intent = await stripe.paymentIntents.create({ amount: p.total * 100, currency: 'pkr', automatic_payment_methods: { enabled: true } });
  }
  const order = await Order.create({
    user: req.user?._id, items: p.lines, orderType, customer, address, deliveryTime, notes,
    payment: { method: paymentMethod, intentId: intent?.id },
    subtotal: p.subtotal, tax: p.tax, deliveryFee: p.deliveryFee, discount: p.discount, total: p.total, coupon: p.coupon?.code,
    history: [{ status: 'received' }],
  });
  if (p.coupon) await Coupon.updateOne({ _id: p.coupon._id }, { $inc: { usedCount: 1 } });
  if (customer.email) sendMail(customer.email, `Order ${order.orderId} confirmed`, orderEmail(order));
  sendMail(process.env.ADMIN_EMAIL, `New order ${order.orderId} – Rs ${order.total}`, orderEmail(order));
  res.status(201).json({ order, clientSecret: intent?.client_secret });
}));

// Stripe confirms on client; client calls this to mark paid after verification
r.post('/:orderId/confirm-payment', wrap(async (req, res) => {
  const o = await Order.findOne({ orderId: req.params.orderId });
  if (!o?.payment.intentId) return res.status(404).json({ message: 'Not found' });
  const pi = await stripe.paymentIntents.retrieve(o.payment.intentId);
  o.payment.status = pi.status === 'succeeded' ? 'paid' : 'failed';
  await o.save(); res.json(o);
}));

r.get('/track/:orderId', wrap(async (req, res) => {
  const o = await Order.findOne({ orderId: req.params.orderId.toUpperCase() }).select('orderId status history orderType total createdAt items');
  o ? res.json(o) : res.status(404).json({ message: 'Order not found' });
}));

r.get('/mine', protect, wrap(async (req, res) => res.json(await Order.find({ user: req.user._id }).sort('-createdAt'))));

// Admin
r.get('/', protect, adminOnly, wrap(async (req, res) => {
  const q = req.query.status ? { status: req.query.status } : {};
  res.json(await Order.find(q).sort('-createdAt').limit(200));
}));
r.put('/:id/status', protect, adminOnly, wrap(async (req, res) => {
  const o = await Order.findById(req.params.id);
  if (!o) return res.status(404).json({ message: 'Not found' });
  o.status = req.body.status; o.history.push({ status: o.status });
  if (o.status === 'delivered' && o.payment.method === 'cod') o.payment.status = 'paid';
  await o.save(); res.json(o);
}));
r.get('/admin/stats', protect, adminOnly, wrap(async (_req, res) => {
  const since = new Date(Date.now() - 30 * 864e5);
  const [totals] = await Order.aggregate([{ $match: { status: { $ne: 'cancelled' } } },
    { $group: { _id: null, revenue: { $sum: '$total' }, orders: { $sum: 1 } } }]);
  const daily = await Order.aggregate([{ $match: { createdAt: { $gte: since }, status: { $ne: 'cancelled' } } },
    { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, sales: { $sum: '$total' }, orders: { $sum: 1 } } },
    { $sort: { _id: 1 } }]);
  const top = await Order.aggregate([{ $unwind: '$items' }, { $group: { _id: '$items.name', qty: { $sum: '$items.qty' } } },
    { $sort: { qty: -1 } }, { $limit: 5 }]);
  res.json({ revenue: totals?.revenue || 0, orders: totals?.orders || 0, daily, top });
}));

export default r;
