import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import Lenis from 'lenis';
import { ShoppingBag, Sun, Moon, Menu, X, User, MessageCircle, Plus, Minus, Trash2, Facebook, Instagram } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import { useApp, money } from '../context';
import { Img } from './ui';
const links = [['/', 'Home'], ['/menu', 'Menu'], ['/order', 'Order Online'], ['/offers', 'Offers'], ['/reservation', 'Reservation'], ['/gallery', 'Gallery'], ['/about', 'About'], ['/contact', 'Contact']];
const WA = import.meta.env.VITE_WHATSAPP || '923001234567';

function Navbar() {
  const { count, dark, setDark, setDrawer, user, bump } = useApp(); const [solid, setSolid] = useState(false); const [open, setOpen] = useState(false); const loc = useLocation();
  useEffect(() => { const f = () => setSolid(scrollY > 40); f(); addEventListener('scroll', f); return () => removeEventListener('scroll', f); }, []);
  useEffect(() => setOpen(false), [loc.pathname]);
  return <header className={`fixed top-0 inset-x-0 z-40 transition-all duration-300 ${solid ? 'bg-cream/95 dark:bg-night/95 backdrop-blur shadow-lg py-2' : 'py-4'}`}>
    <nav className="container-x flex items-center justify-between" aria-label="Main">
      <Link to="/" className="font-heading text-2xl font-extrabold"><span className="text-brand">Spice</span> <span className="text-gold">Orbit</span></Link>
      <ul className="hidden lg:flex gap-6 text-sm font-medium">{links.map(([to, l]) => <li key={to}><NavLink to={to} className={({ isActive }) => `hover:text-gold transition ${isActive ? 'text-gold' : !solid && loc.pathname === '/' ? 'text-white' : ''}`}>{l}</NavLink></li>)}</ul>
      <div className={`flex items-center gap-3 ${!solid && loc.pathname === '/' ? 'text-white' : ''}`}>
        <button aria-label="Toggle theme" onClick={() => setDark(!dark)}>{dark ? <Sun size={20} /> : <Moon size={20} />}</button>
        <Link to={user ? '/profile' : '/login'} aria-label="Account"><User size={20} /></Link>
        <button aria-label="Open cart" className="relative" onClick={() => setDrawer(true)}><ShoppingBag size={22} />
          {count > 0 && <motion.span key={bump} initial={{ scale: 2 }} animate={{ scale: 1 }} className="absolute -top-2 -right-2 bg-brand text-white text-[10px] w-5 h-5 rounded-full grid place-items-center">{count}</motion.span>}</button>
        <button className="lg:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div></nav>
    <AnimatePresence>{open && <motion.ul initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="lg:hidden overflow-hidden bg-cream dark:bg-night text-stone-800 dark:text-white px-6">
      {links.map(([to, l]) => <li key={to}><NavLink to={to} className="block py-3 border-b border-white/10">{l}</NavLink></li>)}</motion.ul>}</AnimatePresence></header>;
}

function CartDrawer() {
  const { drawer, setDrawer, cart, setQty } = useApp(); const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  return <AnimatePresence>{drawer && <>
    <motion.div className="fixed inset-0 bg-black/60 z-50" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setDrawer(false)} />
    <motion.aside role="dialog" aria-label="Cart" className="fixed right-0 top-0 h-full w-full max-w-md z-50 bg-cream dark:bg-night p-6 flex flex-col" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 30 }}>
      <div className="flex justify-between items-center mb-4"><h2 className="text-2xl font-bold">Your Cart</h2><button aria-label="Close" onClick={() => setDrawer(false)}><X /></button></div>
      <div className="flex-1 overflow-y-auto space-y-3">{!cart.length && <div className="text-center mt-20"><div className="text-7xl">🍽️</div><p className="opacity-70 mt-3">Your cart is empty</p></div>}
        {cart.map(i => <div key={i.key} className="glass p-3 flex gap-3 items-center"><Img src={i.image} alt={i.name} className="w-16 h-16 rounded-xl object-cover" />
          <div className="flex-1"><p className="font-semibold">{i.name}</p><p className="text-xs opacity-70">{i.size} {i.addons?.join(', ')}</p><p className="text-gold text-sm">{money(i.price)}</p></div>
          <div className="flex items-center gap-2"><button aria-label="Decrease" onClick={() => setQty(i.key, i.qty - 1)}><Minus size={16} /></button><span>{i.qty}</span><button aria-label="Increase" onClick={() => setQty(i.key, i.qty + 1)}><Plus size={16} /></button></div></div>)}</div>
      <div className="pt-4 border-t border-white/10"><div className="flex justify-between font-bold text-lg mb-3"><span>Subtotal</span><span>{money(total)}</span></div>
        <div className="grid grid-cols-2 gap-3"><Link to="/cart" onClick={() => setDrawer(false)} className="btn btn-ghost">View Cart</Link><Link to="/checkout" onClick={() => setDrawer(false)} className="btn btn-primary">Checkout</Link></div></div>
    </motion.aside></>}</AnimatePresence>;
}

export default function Layout() {
  const loc = useLocation(); const [boot, setBoot] = useState(true);
  useEffect(() => { const t = setTimeout(() => setBoot(false), 1400); return () => clearTimeout(t); }, []);
  useEffect(() => { const l = new Lenis(); let id; const raf = t => { l.raf(t); id = requestAnimationFrame(raf); }; id = requestAnimationFrame(raf); return () => { cancelAnimationFrame(id); l.destroy(); }; }, []);
  return <>
    <AnimatePresence>{boot && <motion.div exit={{ opacity: 0 }} className="fixed inset-0 z-[100] bg-night grid place-items-center"><motion.h1 initial={{ scale: .6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: .8 }} className="font-heading text-5xl font-extrabold text-brand">Spice <span className="text-gold">Orbit</span></motion.h1></motion.div>}</AnimatePresence>
    <Toaster position="top-center" toastOptions={{ style: { borderRadius: 999 } }} /><Navbar /><CartDrawer />
    <AnimatePresence mode="wait"><motion.main key={loc.pathname} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: .3 }}><Outlet /></motion.main></AnimatePresence>
    <footer className="bg-night text-stone-300 pt-14 pb-24 lg:pb-8"><div className="container-x grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
      <div><h3 className="font-heading text-2xl text-white mb-3"><span className="text-brand">Spice</span> Orbit</h3><p className="text-sm">Authentic Pakistani flavours, cooked over charcoal in the heart of Karachi.</p></div>
      <div><h4 className="text-white font-semibold mb-3">Explore</h4>{links.slice(1, 6).map(([t, l]) => <Link key={t} to={t} className="block text-sm py-1 hover:text-gold">{l}</Link>)}</div>
      <div><h4 className="text-white font-semibold mb-3">Info</h4>{[['/faq', 'FAQ'], ['/blog', 'Blog'], ['/reviews', 'Reviews'], ['/privacy', 'Privacy'], ['/terms', 'Terms']].map(([t, l]) => <Link key={t} to={t} className="block text-sm py-1 hover:text-gold">{l}</Link>)}</div>
      <div><h4 className="text-white font-semibold mb-3">Visit</h4><p className="text-sm">Clifton, Karachi<br />Daily 12pm – 1am<br />+92 300 1234567</p><div className="flex gap-3 mt-3"><Facebook size={20} /><Instagram size={20} /></div></div></div>
      <p className="text-center text-xs mt-10 opacity-60">© {new Date().getFullYear()} Spice Orbit. All rights reserved.</p></footer>
    <a href={`https://wa.me/${WA}`} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="fixed bottom-20 lg:bottom-6 right-4 z-40 bg-green-500 text-white p-3 rounded-full shadow-xl hover:scale-110 transition"><MessageCircle /></a>
    <Link to="/order" className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-gradient-to-r from-brand to-orange-500 text-white text-center font-semibold py-4">Order Now</Link></>;
}
