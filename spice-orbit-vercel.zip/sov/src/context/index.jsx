import { createContext, useContext, useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import api from '../api';
const Ctx = createContext();
export const useApp = () => useContext(Ctx);
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
export function AppProvider({ children }) {
  const [user, setUser] = useState(() => load('user', null));
  const [cart, setCart] = useState(() => load('cart', []));
  const [dark, setDark] = useState(() => localStorage.getItem('theme') !== 'light');
  const [drawer, setDrawer] = useState(false);
  const [bump, setBump] = useState(0);
  const [coupon, setCoupon] = useState('');
  const [orderType, setOrderType] = useState('delivery');
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); localStorage.setItem('theme', dark ? 'dark' : 'light'); }, [dark]);
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
    if (user) api.put('/auth/cart', { items: cart.map(({ dish, qty, size, addons }) => ({ dish, qty, size, addons })) }).catch(() => {});
  }, [cart, user]);
  const add = (item, qty = 1) => {
    const key = [item.dish, item.size, (item.addons || []).join()].join('|');
    setCart(c => c.some(i => i.key === key) ? c.map(i => i.key === key ? { ...i, qty: i.qty + qty } : i) : [...c, { ...item, key, qty }]);
    setBump(b => b + 1); toast.success(`${item.name} added to cart`, { icon: '🛒' });
  };
  const setQty = (key, q) => setCart(c => q < 1 ? c.filter(i => i.key !== key) : c.map(i => i.key === key ? { ...i, qty: q } : i));
  const clear = () => { setCart([]); setCoupon(''); };
  const count = cart.reduce((s, i) => s + i.qty, 0);
  const login = ({ token, user }) => { localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user)); setUser(user); };
  const logout = () => { localStorage.removeItem('token'); localStorage.removeItem('user'); setUser(null); };
  return <Ctx.Provider value={{ user, login, logout, cart, add, setQty, clear, count, dark, setDark, drawer, setDrawer, bump, coupon, setCoupon, orderType, setOrderType }}>{children}</Ctx.Provider>;
}
export const money = n => 'Rs ' + Math.round(n || 0).toLocaleString();
