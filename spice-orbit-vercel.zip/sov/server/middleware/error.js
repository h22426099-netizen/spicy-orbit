export const notFound = (req, res) => res.status(404).json({ message: `Route not found: ${req.originalUrl}` });
export const errorHandler = (err, _req, res, _next) => {
  let status = res.statusCode >= 400 ? res.statusCode : err.status || 500;
  let message = err.message;
  if (err.name === 'ValidationError') { status = 400; message = Object.values(err.errors).map(e => e.message).join(', '); }
  if (err.code === 11000) { status = 409; message = 'Duplicate value: ' + Object.keys(err.keyValue).join(', '); }
  if (err.name === 'CastError') { status = 400; message = 'Invalid ID'; }
  res.status(status).json({ message, stack: process.env.NODE_ENV === 'production' ? undefined : err.stack });
};
export const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
