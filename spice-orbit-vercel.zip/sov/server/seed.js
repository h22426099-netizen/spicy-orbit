import 'dotenv/config';
import bcrypt from 'bcryptjs';
import connectDB from './config/db.js';
import User from './models/User.js';
import Category from './models/Category.js';
import Dish from './models/Dish.js';
import Coupon from './models/Coupon.js';

const cats = [
  { name: 'BBQ & Grill', slug: 'bbq-grill', description: 'Charcoal-fired tikka, seekh & malai boti' },
  { name: 'Karahi & Handi', slug: 'karahi-handi', description: 'Slow-cooked, wok-fired classics' },
  { name: 'Biryani & Rice', slug: 'biryani-rice', description: 'Fragrant Karachi-style dum biryani' },
  { name: 'Breads & Sides', slug: 'breads-sides', description: 'Fresh naan, raita and salads' },
  { name: 'Desserts & Drinks', slug: 'desserts-drinks', description: 'Kheer, gulab jamun, lassi & chai' },
];
const SIZES = [{ name: 'Half', priceDelta: 0 }, { name: 'Full', priceDelta: 800 }];
const D = (c, name, price, spicy, isVeg, desc, ing, prompt, extra = {}) => ({
  cat: c, name, price, spicy, isVeg, description: desc, ingredients: ing,
  aiPrompt: prompt, image: `/images/dishes/${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.webp`, ...extra });
const dishes = [
  D('karahi-handi', 'Chicken Karahi', 1650, 3, false, 'Wok-fired chicken with tomatoes, ginger, green chilli and fresh coriander.', ['Chicken', 'Tomato', 'Ginger', 'Green chilli', 'Coriander'],
    'Ultra realistic close-up of sizzling chicken karahi in a black wok, steam rising, dark moody background, professional food photography, 8k', { featured: true, chefSpecial: true, sizes: SIZES }),
  D('karahi-handi', 'Mutton Handi', 2400, 2, false, 'Tender mutton slow-cooked in a clay handi with whole spices and cream.', ['Mutton', 'Yogurt', 'Cream', 'Whole spices'],
    'Rustic clay handi of creamy mutton curry, garnished with ginger julienne, warm rim light, food photography', { sizes: SIZES }),
  D('bbq-grill', 'Chicken Tikka', 950, 2, false, 'Charcoal-grilled chicken marinated overnight in yogurt and spices.', ['Chicken', 'Yogurt', 'Lemon', 'Tikka masala'],
    'Charcoal-grilled chicken tikka pieces on skewers with smoke, lemon wedges, onion rings, dark background, 8k food photo', { featured: true }),
  D('bbq-grill', 'Beef Seekh Kebab', 1100, 3, false, 'Hand-minced beef kebabs with green chilli, grilled over live coals.', ['Beef mince', 'Green chilli', 'Coriander', 'Garam masala'],
    'Sizzling beef seekh kebabs on a grill with flames, close-up, shallow depth of field, professional photography', { featured: true }),
  D('bbq-grill', 'Malai Boti', 1250, 1, false, 'Creamy, melt-in-mouth chicken boti with cream and white pepper.', ['Chicken', 'Cream', 'Cheese', 'White pepper'],
    'Creamy malai boti skewers, golden char marks, served on a wooden board with mint chutney, soft light', {}),
  D('biryani-rice', 'Karachi Chicken Biryani', 1200, 2, false, 'Aromatic basmati layered with spiced chicken, potatoes and saffron.', ['Basmati rice', 'Chicken', 'Potato', 'Saffron', 'Fried onion'],
    'Steaming plate of Karachi chicken biryani with raita and lemon, copper pot behind, warm golden light, 8k', { featured: true, chefSpecial: true }),
  D('biryani-rice', 'Vegetable Pulao', 850, 1, true, 'Fragrant rice cooked with seasonal vegetables and whole spices.', ['Basmati rice', 'Carrot', 'Peas', 'Cumin'],
    'Colourful vegetable pulao in a ceramic bowl, steam, top-down food photography', {}),
  D('breads-sides', 'Garlic Naan', 150, 0, true, 'Tandoor-baked naan brushed with garlic butter.', ['Flour', 'Garlic', 'Butter'],
    'Fresh garlic naan from tandoor, blistered, brushed with butter, cloth-lined basket, close-up', {}),
  D('desserts-drinks', 'Gulab Jamun', 450, 0, true, 'Warm milk dumplings in cardamom-rose syrup.', ['Khoya', 'Sugar', 'Cardamom', 'Rose water'],
    'Three glossy gulab jamun in syrup with pistachio dust, brass bowl, dark moody background, 8k', {}),
  D('desserts-drinks', 'Sweet Lassi', 350, 0, true, 'Chilled churned yogurt drink topped with malai.', ['Yogurt', 'Sugar', 'Cream'],
    'Tall glass of sweet lassi with malai and pistachios, condensation droplets, bright background', {}),
];

await connectDB();
await Promise.all([User.deleteMany(), Category.deleteMany(), Dish.deleteMany(), Coupon.deleteMany()]);
const catDocs = await Category.insertMany(cats.map((c, i) => ({ ...c, order: i, image: `/images/categories/${c.slug}.webp` })));
const byslug = Object.fromEntries(catDocs.map(c => [c.slug, c._id]));
await Dish.create(dishes.map(({ cat, ...d }) => ({ ...d, category: byslug[cat],
  addons: d.isVeg ? [] : [{ name: 'Extra raita', price: 80 }, { name: 'Extra naan', price: 150 }] })));
await User.create([
  { name: 'Admin', email: 'admin@spiceorbit.pk', password: 'Admin@123', role: 'admin' },
  { name: 'Ali Khan', email: 'ali@example.com', password: 'User@123' },
]);
await Coupon.create([{ code: 'WELCOME10', type: 'percent', value: 10, minOrder: 1000 }, { code: 'FLAT200', type: 'fixed', value: 200, minOrder: 2000 }]);
console.log('Seeded: 5 categories, 10 dishes (Part 1 sample), admin@spiceorbit.pk / Admin@123');
process.exit(0);
