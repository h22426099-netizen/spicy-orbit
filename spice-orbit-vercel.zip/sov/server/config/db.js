import mongoose from 'mongoose';
// Cached connection: serverless functions re-use it between invocations
let cached = globalThis.__mongo || (globalThis.__mongo = { conn: null, promise: null });
export default async function connectDB() {
  if (cached.conn) return cached.conn;
  if (!process.env.MONGO_URI) throw new Error('MONGO_URI is not set');
  cached.promise ||= mongoose.connect(process.env.MONGO_URI, { bufferCommands: false, serverSelectionTimeoutMS: 8000 });
  cached.conn = await cached.promise;
  return cached.conn;
}
