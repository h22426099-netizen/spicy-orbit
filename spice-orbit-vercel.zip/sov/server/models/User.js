import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
const addressSchema = new mongoose.Schema({ label: String, line: String, city: { type: String, default: 'Karachi' }, phone: String });
const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6, select: false },
  phone: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  addresses: [addressSchema],
  favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Dish' }],
  cart: [{ dish: { type: mongoose.Schema.Types.ObjectId, ref: 'Dish' }, qty: Number, size: String, addons: [String] }],
  resetToken: String, resetExpires: Date,
}, { timestamps: true });
userSchema.pre('save', async function (next) {
  if (this.isModified('password')) this.password = await bcrypt.hash(this.password, 12);
  next();
});
userSchema.methods.matchPassword = function (p) { return bcrypt.compare(p, this.password); };
export default mongoose.model('User', userSchema);
