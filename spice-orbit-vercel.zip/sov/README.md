# Spice Orbit – Vercel ready (single project: React + Express API)
## Local
npm install → cp .env.example .env → npm run seed → npm run dev  (web :5173, api :5000)
## Deploy on Vercel
1. MongoDB Atlas: free cluster → Database Access (user) → Network Access: allow 0.0.0.0/0 → copy URI.
2. Push this folder to GitHub (root of repo = this folder).
3. vercel.com → Add New → Project → import repo (Framework: Vite, auto-detected; no changes needed).
4. Settings → Environment Variables: add everything from .env.example (CLIENT_URL = your Vercel URL).
5. Deploy. Then once, from your PC: put the Atlas URI in local .env and run `npm run seed`.
6. Open https://YOUR-APP.vercel.app/api/health → should show {"ok":true}.
Notes: image uploads max ~4 MB (Vercel body limit). Replace YOUR-DOMAIN in public/sitemap.xml.
