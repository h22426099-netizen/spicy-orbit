import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Minus, Plus, Heart } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../api';
import { useApp, money } from '../context';
import { Img, Stars, Page } from '../components/ui';
import DishCard from '../components/DishCard';
export default function Dish() {
  const { slug } = useParams(); const { add, user } = useApp(); const [d, setD] = useState(null); const [rel, setRel] = useState([]); const [size, setSize] = useState(''); const [ad, setAd] = useState([]); const [q, setQ] = useState(1);
  useEffect(() => { api.get('/dishes/' + slug).then(r => { setD(r.dish); setRel(r.related); setSize(r.dish.sizes?.[0]?.name || ''); setAd([]); setQ(1); }).catch(() => setD(false)); }, [slug]);
  if (d === false) return <Page title="Not found"><p>Dish not found.</p></Page>;
  if (!d) return <Page title="Loading…"><div className="skeleton h-96" /></Page>;
  const unit = d.price + (d.sizes.find(s => s.name === size)?.priceDelta || 0) + ad.reduce((s, n) => s + (d.addons.find(a => a.name === n)?.price || 0), 0);
  return <Page title={d.name}><div className="grid md:grid-cols-2 gap-10">
    <Img src={d.image} alt={d.name} className="rounded-3xl w-full aspect-square object-cover shadow-2xl" />
    <div><Stars n={d.rating} /><p className="my-4 opacity-80">{d.description}</p><p className="text-3xl font-bold text-gold mb-4">{money(unit * q)}</p>
      <h3 className="font-semibold mb-1">Ingredients</h3><div className="flex flex-wrap gap-2 mb-5">{d.ingredients.map(i => <span key={i} className="glass !rounded-full px-3 py-1 text-xs">{i}</span>)}</div>
      {!!d.sizes.length && <div className="mb-4"><h3 className="font-semibold mb-1">Size</h3><div className="flex gap-2">{d.sizes.map(s => <button key={s.name} onClick={() => setSize(s.name)} className={`btn !py-2 ${size === s.name ? 'btn-primary' : 'btn-ghost'}`}>{s.name}{s.priceDelta ? ` +${s.priceDelta}` : ''}</button>)}</div></div>}
      {!!d.addons.length && <div className="mb-4"><h3 className="font-semibold mb-1">Add-ons</h3>{d.addons.map(a => <label key={a.name} className="flex items-center gap-2 py-1"><input type="checkbox" checked={ad.includes(a.name)} onChange={e => setAd(e.target.checked ? [...ad, a.name] : ad.filter(x => x !== a.name))} />{a.name} (+{a.price})</label>)}</div>}
      <div className="flex items-center gap-4 flex-wrap"><div className="glass flex items-center gap-4 px-4 py-2"><button aria-label="Less" onClick={() => setQ(Math.max(1, q - 1))}><Minus size={18} /></button><b>{q}</b><button aria-label="More" onClick={() => setQ(q + 1)}><Plus size={18} /></button></div>
        <button className="btn btn-primary" onClick={() => add({ dish: d._id, slug: d.slug, name: d.name, image: d.image, price: unit, size, addons: ad }, q)}>Add to cart</button>
        {user && <button aria-label="Favorite" className="btn btn-ghost !px-3" onClick={() => api.post('/auth/favorites/' + d._id).then(() => toast.success('Favorites updated'))}><Heart size={18} /></button>}</div></div></div>
    <h2 className="text-3xl font-bold mt-16 mb-6">You may also like</h2><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">{rel.map((r, i) => <DishCard key={r._id} d={r} i={i} />)}</div></Page>;
}
