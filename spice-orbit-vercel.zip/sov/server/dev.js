// Local development only (Vercel uses api/index.js)
import app from './app.js';
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`API on http://localhost:${port}`));
