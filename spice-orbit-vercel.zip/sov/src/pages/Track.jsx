import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Check } from 'lucide-react';
import api from '../api';
import { Page } from '../components/ui';
const steps = [['received', 'Received'], ['preparing', 'Preparing'], ['on_the_way', 'On the way'], ['delivered', 'Delivered']];
export default function Track() {
  const [sp] = useSearchParams(); const [id, setId] = useState(sp.get('id') || ''); const [o, setO] = useState(null); const [err, setErr] = useState('');
  const go = (v = id) => api.get('/orders/track/' + v.trim()).then(r => { setO(r); setErr(''); }).catch(e => { setO(null); setErr(e.message); });
  useEffect(() => { if (sp.get('id')) go(sp.get('id')); }, []);
  useEffect(() => { if (!o) return; const t = setInterval(() => go(o.orderId), 15000); return () => clearInterval(t); }, [o?.orderId]);
  const idx = o ? steps.findIndex(s => s[0] === o.status) : -1;
  return <Page title="Track Your Order"><form onSubmit={e => { e.preventDefault(); go(); }} className="flex gap-3 max-w-lg"><input className="input" placeholder="Order ID e.g. SO-XXXX" value={id} onChange={e => setId(e.target.value)} /><button className="btn btn-primary">Track</button></form>
    {err && <p className="text-red-500 mt-4">{err}</p>}
    {o && <div className="glass p-8 mt-8"><p className="mb-6">Order <b>{o.orderId}</b> · {o.status === 'cancelled' ? 'Cancelled' : 'Live status'}</p>
      <ol className="grid grid-cols-4 gap-2 text-center">{steps.map(([k, l], i) => <li key={k}><div className={`mx-auto w-12 h-12 rounded-full grid place-items-center ${i <= idx ? 'bg-green-500 text-white' : 'bg-stone-300 dark:bg-white/10'} ${i === idx ? 'ring-4 ring-green-500/30' : ''}`}>{i <= idx ? <Check /> : i + 1}</div><p className="text-xs sm:text-sm mt-2">{l}</p></li>)}</ol></div>}</Page>;
}
