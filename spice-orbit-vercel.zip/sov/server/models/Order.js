import mongoose from 'mongoose';
const orderSchema = new mongoose.Schema({
  orderId: { type: String, unique: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{ dish: { type: mongoose.Schema.Types.ObjectId, ref: 'Dish' }, name: String, image: String,
    price: Number, qty: Number, size: String, addons: [String] }],
  orderType: { type: String, enum: ['delivery', 'takeaway', 'dine-in'], default: 'delivery' },
  customer: { name: String, phone: String, email: String },
  address: { line: String, city: String },
  deliveryTime: String, notes: String,
  payment: { method: { type: String, enum: ['cod', 'stripe'], default: 'cod' },
    status: { type: String, enum: ['pending', 'paid', 'failed'], default: 'pending' }, intentId: String },
  subtotal: Number, tax: Number, deliveryFee: Number, discount: Number, total: Number, coupon: String,
  status: { type: String, enum: ['received', 'preparing', 'on_the_way', 'delivered', 'cancelled'], default: 'received' },
  history: [{ status: String, at: { type: Date, default: Date.now } }],
}, { timestamps: true });
orderSchema.pre('validate', function (next) {
  if (!this.orderId) this.orderId = 'SO-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase();
  next();
});
export default mongoose.model('Order', orderSchema);
