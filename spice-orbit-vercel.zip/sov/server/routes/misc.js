import { Router } from 'express';
import Category from '../models/Category.js';
import Coupon from '../models/Coupon.js';
import Reservation from '../models/Reservation.js';
import Review from '../models/Review.js';
import User from '../models/User.js';
import { protect, adminOnly, optionalAuth } from '../middleware/auth.js';
import { wrap } from '../middleware/error.js';
import { crud } from '../utils/crud.js';
import { sendMail } from '../utils/mailer.js';

const r = Router();
const A = [protect, adminOnly];

// Categories
const cat = crud(Category);
r.get('/categories', (req, _res, next) => { req.sort = 'order'; next(); }, cat.list);
r.post('/categories', ...A, (req, _res, next) => { req.body.slug ||= req.body.name?.toLowerCase().replace(/[^a-z0-9]+/g, '-'); next(); }, cat.create);
r.put('/categories/:id', ...A, cat.update);
r.delete('/categories/:id', ...A, cat.remove);

// Coupons (admin) + public list of active offers
const cp = crud(Coupon);
r.get('/offers', wrap(async (_q, res) => res.json(await Coupon.find({ active: true, $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }).select('-usedCount'))));
r.get('/coupons', ...A, cp.list);
r.post('/coupons', ...A, cp.create);
r.put('/coupons/:id', ...A, cp.update);
r.delete('/coupons/:id', ...A, cp.remove);

// Reservations
const rs = crud(Reservation);
r.post('/reservations', wrap(async (req, res) => {
  const doc = await Reservation.create(req.body);
  await sendMail(doc.email, 'Table request received – Spice Orbit',
    `<p>Hi ${doc.name}, we received your request for ${doc.guests} guests on ${doc.date} at ${doc.time}. We'll confirm shortly.</p>`);
  await sendMail(process.env.ADMIN_EMAIL, 'New reservation', `<p>${doc.name} – ${doc.guests} guests – ${doc.date} ${doc.time}</p>`);
  res.status(201).json(doc);
}));
r.get('/reservations', ...A, rs.list);
r.put('/reservations/:id', ...A, wrap(async (req, res) => {
  const doc = await Reservation.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (doc && req.body.status === 'confirmed')
    await sendMail(doc.email, 'Your table is confirmed', `<p>See you on ${doc.date} at ${doc.time}, ${doc.name}!</p>`);
  res.json(doc);
}));
r.delete('/reservations/:id', ...A, rs.remove);

// Reviews
const rv = crud(Review);
r.get('/reviews', (req, _res, next) => { req.filter = { approved: true }; next(); }, rv.list);
r.post('/reviews', optionalAuth, wrap(async (req, res) => {
  const { name, rating, comment, dish } = req.body;
  res.status(201).json(await Review.create({ name: name || req.user?.name, rating, comment, dish, user: req.user?._id }));
}));
r.get('/admin/reviews', ...A, wrap(async (_q, res) => res.json(await Review.find().sort('-createdAt'))));
r.put('/reviews/:id', ...A, rv.update);
r.delete('/reviews/:id', ...A, rv.remove);

// Admin: users
r.get('/users', ...A, wrap(async (_q, res) => res.json(await User.find().sort('-createdAt'))));
r.put('/users/:id/role', ...A, wrap(async (req, res) => res.json(await User.findByIdAndUpdate(req.params.id, { role: req.body.role }, { new: true }))));
r.delete('/users/:id', ...A, wrap(async (req, res) => { await User.findByIdAndDelete(req.params.id); res.json({ message: 'Deleted' }); }));

// Newsletter + contact (emailed to admin)
r.post('/newsletter', wrap(async (req, res) => { await sendMail(process.env.ADMIN_EMAIL, 'New newsletter signup', `<p>${req.body.email}</p>`); res.json({ message: 'Subscribed!' }); }));
r.post('/contact', wrap(async (req, res) => {
  const { name, email, message } = req.body;
  await sendMail(process.env.ADMIN_EMAIL, `Contact: ${name}`, `<p>${email}</p><p>${message}</p>`);
  res.json({ message: 'Message sent' });
}));

export default r;
