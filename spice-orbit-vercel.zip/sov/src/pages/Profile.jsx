import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../api';
import { useApp, money } from '../context';
import { Page } from '../components/ui';
import DishCard from '../components/DishCard';
export default function Profile() {
  const { user, logout } = useApp(); const nav = useNavigate(); const [orders, setOrders] = useState([]); const [favs, setFavs] = useState([]); const [addr, setAddr] = useState('');
  useEffect(() => { api.get('/orders/mine').then(setOrders).catch(() => {}); api.get('/auth/favorites').then(setFavs).catch(() => {}); }, []);
  return <Page title={`Hello, ${user?.name}`}><div className="flex gap-3 mb-8">{user?.role === 'admin' && <Link to="/admin" className="btn btn-primary">Admin dashboard</Link>}<button className="btn btn-ghost" onClick={() => { logout(); nav('/'); }}>Logout</button></div>
    <h2 className="text-2xl font-bold mb-3">Order history</h2><div className="space-y-2 mb-10">{orders.map(o => <div key={o._id} className="glass p-4 flex flex-wrap justify-between gap-2"><span>{o.orderId} · {new Date(o.createdAt).toLocaleDateString()}</span><span>{money(o.total)}</span><Link to={`/track?id=${o.orderId}`} className="text-gold capitalize">{o.status.replace(/_/g, ' ')} →</Link></div>)}{!orders.length && <p className="opacity-60">No orders yet.</p>}</div>
    <h2 className="text-2xl font-bold mb-3">Saved address</h2><form className="flex gap-2 mb-10 max-w-lg" onSubmit={async e => { e.preventDefault(); await api.put('/auth/profile', { addresses: [{ label: 'Home', line: addr, city: 'Karachi' }] }); toast.success('Saved'); }}><input className="input" placeholder="Address" value={addr} onChange={e => setAddr(e.target.value)} /><button className="btn btn-primary">Save</button></form>
    <h2 className="text-2xl font-bold mb-3">Favorites</h2><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">{favs.map(d => <DishCard key={d._id} d={d} />)}</div></Page>;
}
