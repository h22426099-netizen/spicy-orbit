import mongoose from 'mongoose';
export default mongoose.model('Category', new mongoose.Schema({
  name: { type: String, required: true, unique: true }, slug: { type: String, unique: true },
  image: String, description: String, order: { type: Number, default: 0 },
}, { timestamps: true }));
