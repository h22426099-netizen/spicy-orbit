import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Star } from 'lucide-react';
export function Img({ src, alt, className = '' }) {
  const [bad, setBad] = useState(!src);
  return bad ? <div role="img" aria-label={alt} className={`${className} grid place-items-center bg-gradient-to-br from-brand/80 to-gold/80 text-5xl`}>🍛</div>
    : <img loading="lazy" src={src} alt={alt} onError={() => setBad(true)} className={className} />;
}
export const Stars = ({ n = 5 }) => <span className="inline-flex text-gold" aria-label={`${n} stars`}>{[1, 2, 3, 4, 5].map(i => <Star key={i} size={14} fill={i <= Math.round(n) ? 'currentColor' : 'none'} />)}</span>;
export const Reveal = ({ children, delay = 0, className = '' }) =>
  <motion.div className={className} initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-60px' }} transition={{ duration: .6, delay }}>{children}</motion.div>;
export const Section = ({ title, sub, children, id }) => <section id={id} className="py-16 sm:py-24"><div className="container-x">
  <Reveal className="text-center mb-12"><p className="text-gold uppercase tracking-[.3em] text-xs mb-2">{sub}</p><h2 className="text-3xl sm:text-5xl font-bold">{title}</h2></Reveal>{children}</div></section>;
export function Counter({ to, suffix = '' }) {
  const ref = useRef(), inView = useInView(ref, { once: true }); const [n, setN] = useState(0);
  useEffect(() => { if (!inView) return; let s = 0; const t = setInterval(() => { s += to / 60; if (s >= to) { s = to; clearInterval(t); } setN(Math.floor(s)); }, 25); return () => clearInterval(t); }, [inView, to]);
  return <span ref={ref}>{n.toLocaleString()}{suffix}</span>;
}
export const Skeletons = ({ n = 6 }) => <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">{Array.from({ length: n }).map((_, i) => <div key={i} className="skeleton h-80" />)}</div>;
export const Page = ({ title, children }) => { useEffect(() => { document.title = `${title} | Spice Orbit`; window.scrollTo(0, 0); }, [title]);
  return <div className="container-x pt-28 pb-20 min-h-screen"><h1 className="text-4xl sm:text-5xl font-bold mb-8">{title}</h1>{children}</div>; };
export const Field = ({ label, error, children }) => <label className="block"><span className="text-sm font-medium">{label}</span>{children}{error && <p className="err">{error.message}</p>}</label>;
