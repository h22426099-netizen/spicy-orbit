const base = import.meta.env.VITE_API_URL || '/api';
async function req(method, url, body) {
  const t = localStorage.getItem('token'); const form = body instanceof FormData;
  const r = await fetch(base + url, { method, headers: { ...(t && { Authorization: 'Bearer ' + t }), ...(body && !form && { 'Content-Type': 'application/json' }) }, body: form ? body : body && JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.message || 'Request failed');
  return d;
}
export default { get: u => req('GET', u), post: (u, b) => req('POST', u, b), put: (u, b) => req('PUT', u, b), del: u => req('DELETE', u) };
