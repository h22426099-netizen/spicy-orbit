import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Page } from '../components/ui';
export default function Confirm() {
  const { id } = useParams();
  return <Page title="Order Confirmed"><div className="text-center py-10"><svg className="mx-auto" width="120" height="120" viewBox="0 0 120 120"><motion.circle cx="60" cy="60" r="54" fill="none" stroke="#22c55e" strokeWidth="6" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: .7 }} />
    <motion.path d="M34 62l18 18 34-38" fill="none" stroke="#22c55e" strokeWidth="8" strokeLinecap="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: .6, duration: .5 }} /></svg>
    <h2 className="text-3xl font-bold mt-6">Thank you! Your order is in.</h2><p className="my-3">Order ID: <b className="text-gold text-xl">{id}</b></p><p className="opacity-70 mb-6">A confirmation email is on its way.</p>
    <div className="flex gap-3 justify-center"><Link to={`/track?id=${id}`} className="btn btn-primary">Track order</Link><Link to="/menu" className="btn btn-ghost">Order more</Link></div></div></Page>;
}
