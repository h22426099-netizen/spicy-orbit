import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../api';
import { useApp, money } from '../context';
import { Img, Page } from '../components/ui';
export const useQuote = () => {
  const { cart, coupon, orderType } = useApp(); const [q, setQ] = useState(null);
  useEffect(() => { if (!cart.length) return setQ(null); api.post('/orders/quote', { items: cart.map(({ dish, qty, size, addons }) => ({ dish, qty, size, addons })), orderType, coupon }).then(setQ).catch(() => {}); }, [cart, coupon, orderType]);
  return q;
};
export const Summary = ({ q }) => q ? <div className="glass p-6 space-y-2"><h3 className="font-bold text-xl mb-2">Order Summary</h3>
  {[['Subtotal', q.subtotal], ['Discount', -q.discount], ['Tax', q.tax], ['Delivery', q.deliveryFee]].map(([l, v]) => <div key={l} className="flex justify-between text-sm"><span>{l}</span><span>{money(v)}</span></div>)}
  <div className="flex justify-between font-bold text-lg border-t border-white/20 pt-2"><span>Total</span><span className="text-gold">{money(q.total)}</span></div></div> : null;
export default function Cart() {
  const { cart, setQty, coupon, setCoupon } = useApp(); const q = useQuote(); const [code, setCode] = useState(coupon);
  if (!cart.length) return <Page title="Cart"><div className="text-center py-20"><div className="text-8xl">🛒</div><p className="my-4">Your cart is empty.</p><Link to="/menu" className="btn btn-primary">Browse menu</Link></div></Page>;
  return <Page title="Your Cart"><div className="grid lg:grid-cols-3 gap-8"><div className="lg:col-span-2 space-y-3">
    {cart.map(i => <div key={i.key} className="glass p-4 flex gap-4 items-center"><Img src={i.image} alt={i.name} className="w-20 h-20 rounded-xl object-cover" /><div className="flex-1"><p className="font-bold">{i.name}</p><p className="text-xs opacity-70">{i.size} {i.addons?.join(', ')}</p><p className="text-gold">{money(i.price * i.qty)}</p></div>
      <div className="flex items-center gap-2"><button aria-label="Less" onClick={() => setQty(i.key, i.qty - 1)}><Minus size={16} /></button><b>{i.qty}</b><button aria-label="More" onClick={() => setQty(i.key, i.qty + 1)}><Plus size={16} /></button></div>
      <button aria-label="Remove" onClick={() => setQty(i.key, 0)} className="text-red-500"><Trash2 size={18} /></button></div>)}</div>
    <div className="space-y-4"><div className="glass p-4 flex gap-2"><input className="input" placeholder="Coupon code" value={code} onChange={e => setCode(e.target.value)} /><button className="btn btn-ghost" onClick={() => { setCoupon(code); toast(code ? 'Coupon applied if valid' : 'Removed'); }}>Apply</button></div>
      <Summary q={q} /><Link to="/checkout" className="btn btn-primary w-full">Proceed to Checkout</Link></div></div></Page>;
}
