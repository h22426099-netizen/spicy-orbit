# Spice Orbit – Karachi (Pakistani Cuisine)
## Part 1: Backend
1. `cd backend && npm install`
2. `cp .env.example .env` and fill values (MongoDB URI, JWT secret; Cloudinary/Stripe/SMTP optional while testing)
3. `npm run seed`  → admin@spiceorbit.pk / Admin@123
4. `npm run dev`   → http://localhost:5000/api/health
