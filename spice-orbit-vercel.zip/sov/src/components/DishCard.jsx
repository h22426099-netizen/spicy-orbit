import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Flame } from 'lucide-react';
import { useApp, money } from '../context';
import { Img, Stars } from './ui';
export default function DishCard({ d, i = 0 }) {
  const { add } = useApp();
  return <motion.article initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 3) * .08 }}
    whileHover={{ y: -8 }} className="glass overflow-hidden group flex flex-col">
    <Link to={`/dish/${d.slug}`} className="block overflow-hidden relative aspect-[4/3]">
      <Img src={d.image} alt={d.name} className="w-full h-full object-cover transition duration-700 group-hover:scale-110" />
      <span className={`absolute top-3 left-3 w-5 h-5 rounded border-2 bg-white grid place-items-center ${d.isVeg ? 'border-green-600' : 'border-red-600'}`}><i className={`w-2.5 h-2.5 rounded-full ${d.isVeg ? 'bg-green-600' : 'bg-red-600'}`} /></span>
    </Link>
    <div className="p-5 flex-1 flex flex-col">
      <div className="flex justify-between items-start gap-2"><h3 className="text-xl font-bold">{d.name}</h3><span className="text-gold font-semibold whitespace-nowrap">{money(d.price)}</span></div>
      <p className="text-sm opacity-70 mt-1 line-clamp-2 flex-1">{d.description}</p>
      <div className="flex items-center justify-between mt-4"><div><Stars n={d.rating} /><div className="flex text-brand mt-1">{Array.from({ length: d.spicy }).map((_, k) => <Flame key={k} size={14} />)}</div></div>
        <button aria-label={`Add ${d.name} to cart`} className="btn btn-primary !px-4 !py-2 text-sm"
          onClick={() => add({ dish: d._id, slug: d.slug, name: d.name, image: d.image, price: d.price + (d.sizes?.[0]?.priceDelta || 0), size: d.sizes?.[0]?.name, addons: [] })}><Plus size={16} />Add</button></div>
    </div></motion.article>;
}
