import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import connectDB from './config/db.js';
import { notFound, errorHandler } from './middleware/error.js';
import auth from './routes/auth.js';
import dishes from './routes/dishes.js';
import orders from './routes/orders.js';
import misc from './routes/misc.js';

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.CLIENT_URL?.split(','), credentials: true }));
app.use(express.json({ limit: '1mb' }));
if (process.env.NODE_ENV !== 'production') app.use(morgan('dev'));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 600 }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }));

app.get('/api/health', (_q, res) => res.json({ ok: true, name: 'Spice Orbit API' }));
app.use('/api/auth', auth);
app.use('/api/dishes', dishes);
app.use('/api/orders', orders);
app.use('/api', misc);
app.use(notFound);
app.use(errorHandler);

connectDB().then(() => app.listen(process.env.PORT || 5000, () => console.log(`API on :${process.env.PORT || 5000}`)))
  .catch(e => { console.error(e); process.exit(1); });
