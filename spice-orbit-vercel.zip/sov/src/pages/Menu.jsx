import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import api from '../api';
import DishCard from '../components/DishCard';
import { Page, Skeletons } from '../components/ui';
import { useApp } from '../context';
export default function Menu({ order }) {
  const [sp, setSp] = useSearchParams(); const [cats, setCats] = useState([]); const [data, setData] = useState(null);
  const [f, setF] = useState({ search: '', veg: '', spicy: '', sort: '-rating', page: 1 }); const { orderType, setOrderType } = useApp(); const cat = sp.get('category') || '';
  useEffect(() => { api.get('/categories').then(setCats).catch(() => {}); }, []);
  useEffect(() => { setData(null); const q = new URLSearchParams({ ...(cat && { category: cat }), ...Object.fromEntries(Object.entries(f).filter(([, v]) => v !== '')), limit: 9 });
    const t = setTimeout(() => api.get('/dishes?' + q).then(setData).catch(() => setData({ items: [], pages: 1 })), 250); return () => clearTimeout(t); }, [f, cat]);
  const set = (k, v) => setF({ ...f, [k]: v, page: 1 });
  return <Page title={order ? 'Order Online' : 'Our Menu'}>
    {order && <div className="flex gap-2 mb-6 flex-wrap">{['delivery', 'takeaway', 'dine-in'].map(t => <button key={t} onClick={() => setOrderType(t)} className={`btn capitalize ${orderType === t ? 'btn-primary' : 'btn-ghost'}`}>{t}</button>)}</div>}
    <div className="flex gap-2 overflow-x-auto pb-3">{[{ slug: '', name: 'All' }, ...cats].map(c => <button key={c.slug} onClick={() => setSp(c.slug ? { category: c.slug } : {})} className={`btn !py-2 whitespace-nowrap ${cat === c.slug ? 'btn-primary' : 'btn-ghost'}`}>{c.name}</button>)}</div>
    <div className="grid sm:grid-cols-4 gap-3 my-6"><div className="relative sm:col-span-2"><Search className="absolute left-3 top-3.5 opacity-50" size={18} /><input className="input !pl-10" placeholder="Search dishes…" aria-label="Search" value={f.search} onChange={e => set('search', e.target.value)} /></div>
      <select className="input" aria-label="Type" value={f.veg} onChange={e => set('veg', e.target.value)}><option value="">Veg & Non-veg</option><option value="true">Veg</option><option value="false">Non-veg</option></select>
      <select className="input" aria-label="Sort" value={f.sort} onChange={e => set('sort', e.target.value)}><option value="-rating">Top rated</option><option value="price">Price: low–high</option><option value="-price">Price: high–low</option></select></div>
    <div className="flex gap-2 mb-6 text-sm items-center">Spicy:{[['', 'Any'], ['1', '🌶'], ['2', '🌶🌶'], ['3', '🌶🌶🌶']].map(([v, l]) => <button key={v} onClick={() => set('spicy', v)} className={`px-3 py-1 rounded-full border ${f.spicy === v ? 'bg-brand text-white border-brand' : 'border-stone-400'}`}>{l}</button>)}</div>
    {!data ? <Skeletons /> : !data.items.length ? <div className="text-center py-20"><div className="text-7xl">🔍</div><p>No dishes found.</p></div> : <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">{data.items.map((d, i) => <DishCard key={d._id} d={d} i={i} />)}</div>}
    {data?.pages > 1 && <div className="flex justify-center gap-2 mt-10">{Array.from({ length: data.pages }).map((_, i) => <button key={i} onClick={() => setF({ ...f, page: i + 1 })} className={`w-10 h-10 rounded-full ${f.page === i + 1 ? 'bg-brand text-white' : 'glass'}`}>{i + 1}</button>)}</div>}</Page>;
}
