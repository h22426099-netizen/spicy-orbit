import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../api';
import { useApp } from '../context';
import { Page } from '../components/ui';
export default function Auth({ mode }) {
  const { login } = useApp(); const nav = useNavigate(); const { token } = useParams(); const [f, setF] = useState({}); const [busy, setBusy] = useState(false);
  const t = { login: 'Login', signup: 'Create Account', forgot: 'Forgot Password', reset: 'Reset Password' }[mode];
  const submit = async e => { e.preventDefault(); setBusy(true); try {
    if (mode === 'forgot') toast.success((await api.post('/auth/forgot-password', f)).message);
    else { const r = await api.post(mode === 'reset' ? `/auth/reset-password/${token}` : '/auth/' + mode, f); login(r); nav(r.user.role === 'admin' ? '/admin' : '/profile'); }
  } catch (x) { toast.error(x.message); } setBusy(false); };
  const inp = (k, ph, type = 'text') => <input required className="input" type={type} placeholder={ph} aria-label={ph} onChange={e => setF({ ...f, [k]: e.target.value })} />;
  return <Page title={t}><form onSubmit={submit} className="glass p-8 max-w-md mx-auto space-y-4">
    {mode === 'signup' && inp('name', 'Full name')}{mode !== 'reset' && inp('email', 'Email', 'email')}{mode === 'signup' && inp('phone', 'Phone')}{mode !== 'forgot' && inp('password', 'Password', 'password')}
    <button disabled={busy} className="btn btn-primary w-full">{busy ? '…' : t}</button>
    <div className="text-sm flex justify-between">{mode === 'login' ? <><Link to="/signup" className="text-gold">Create account</Link><Link to="/forgot-password" className="text-gold">Forgot password?</Link></> : <Link to="/login" className="text-gold">Back to login</Link>}</div></form></Page>;
}
