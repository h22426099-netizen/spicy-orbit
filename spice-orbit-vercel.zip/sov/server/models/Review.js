import mongoose from 'mongoose';
export default mongoose.model('Review', new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  name: { type: String, required: true }, rating: { type: Number, min: 1, max: 5, required: true },
  comment: { type: String, required: true }, dish: { type: mongoose.Schema.Types.ObjectId, ref: 'Dish' },
  approved: { type: Boolean, default: true },
}, { timestamps: true }));
